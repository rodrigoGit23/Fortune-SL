class Usuario {
  int id;
  String username;
  String password;
  String email;
  int monedasGlobales;

  Usuario({
    required this.id,
    required this.username,
    required this.password,
    required this.email,
    required this.monedasGlobales,
  });
}