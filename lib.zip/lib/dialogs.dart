import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'models.dart';


   Future<void> dialogAviso(BuildContext context, String mensaje, String boton, String s) {
  return showDialog(
    context: context,
    builder: (context) => AlertDialog(
      title: Text(
        mensaje, 
        style: const TextStyle(fontSize: 14), 
        textAlign: TextAlign.center,
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: Text(boton),
        )
      ],
    ),
  );
}

Future<void> dialogRanking(BuildContext context, List<Usuario> listRanking) {
  final formatter = NumberFormat.decimalPattern('es_ES');

  return showDialog(
    context: context,
    barrierDismissible: false,
    builder: (context) => Dialog(
      backgroundColor: Colors.black.withOpacity(0.7),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(25),
        side: BorderSide(color: Colors.brown.withOpacity(0.7), width: 3),
      ),
      child: Padding(
        padding: EdgeInsets.fromLTRB(50, 25, 50, 10),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Ranking 🏆',
              style: TextStyle(
                fontFamily: 'Fell',
                fontSize: 30,
                color: Colors.amber[500],
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 15),
            ListView.builder(
              shrinkWrap: true,
              itemCount: listRanking.length,
              itemBuilder: (context, index) {
                final usuario = listRanking[index];
                return Padding(
                  padding: EdgeInsets.symmetric(vertical: 0),
                  child: Row(
                    children: [
                      Text(
                        '${index + 1}.',
                        style: TextStyle(
                          fontFamily: 'Fell',
                          color: Colors.amber[300],
                          fontSize: 26,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          usuario.username,
                          style: TextStyle(
                            fontFamily: 'Fell',
                            color: Colors.amber[300],
                            fontSize: 22,
                          ),
                        ),
                      ),
                      Text(
                        formatter.format(usuario.monedasGlobales),
                        style: TextStyle(
                          fontFamily: 'Fell',
                          color: Colors.amber[300],
                          fontSize: 26,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
            SizedBox(height: 20),
            SizedBox(
              width: 80,
              child: OutlinedButton(
                onPressed: () => Navigator.of(context).pop(),
                style: OutlinedButton.styleFrom(
                  backgroundColor: Colors.black.withOpacity(0.9),
                  foregroundColor: Colors.amber[200],
                  side: BorderSide(color: Colors.brown.withOpacity(0.9), width: 1.5),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(25),
                  ),
                  padding: EdgeInsets.symmetric(vertical: 5),
                ),
                child: Text(
                  'OK',
                  style: TextStyle(
                    fontFamily: 'Fell',
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    ),
  );
}