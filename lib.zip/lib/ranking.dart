import 'package:flutter/material.dart';
import 'package:suerte/connection.dart';
import 'package:suerte/first.dart';
import 'package:suerte/main.dart'; 
import 'package:suerte/models.dart';

class Ranking extends StatefulWidget {
  @override
  _RankingState createState() => _RankingState();
}

class _RankingState extends State<Ranking> {
  
  final ConexionDB conexion = ConexionDB();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Imagen de fondo
          Container(
            width: double.infinity,
            height: double.infinity,
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage('images/ranking.png'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                // Espacio para que las filas caigan dentro del marco de la imagen
                const SizedBox(height: 160),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 35),
                    child: FutureBuilder<List<Usuario>>(
                      future: conexion.obtenerRanking(),
                      builder: (context, snapshot) {
                        if (snapshot.connectionState == ConnectionState.waiting) {
                          return const Center(child: CircularProgressIndicator(color: Colors.amber));
                        }
                        if (snapshot.hasError) return Center(child: Text("Error: ${snapshot.error}", style: const TextStyle(color: Colors.white)));
                        if (!snapshot.hasData || snapshot.data!.isEmpty) return const Center(child: Text("No hay datos", style: TextStyle(color: Colors.white)));

                        final listaUsuarios = snapshot.data!;

                        return ListView.builder(
                          padding: const EdgeInsets.only(top: 10, bottom: 20),
                          itemCount: listaUsuarios.length,
                          itemBuilder: (context, index) {
                            final user = listaUsuarios[index];
                            return _disenhoFilaRanking(index + 1, user.username, user.monedasGlobales);
                          },
                        );
                      },
                    ),
                  ),
                ),
                // Botón home
                Padding(
                  padding: const EdgeInsets.only(bottom: 20),
                  child: IconButton(
                    icon: const Icon(Icons.home, color: Colors.amber, size: 40),
                    onPressed: () => Navigator.of(context).pushNamedAndRemoveUntil('/login', (route) => false),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _disenhoFilaRanking(int posicion, String nombre, int puntos) {
    Color colorPosicion;
    if (posicion == 1) colorPosicion = Colors.amber;
    else if (posicion == 2) colorPosicion = Colors.grey.shade300;
    else if (posicion == 3) colorPosicion = Colors.brown.shade300;
    else colorPosicion = Colors.white70;

    return Container(
      margin: const EdgeInsets.only(bottom: 6),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.35),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.amber.withOpacity(0.15)),
      ),
      child: Row(
        children: [
          Text(
            "$posicion. ",
            style: TextStyle(color: colorPosicion, fontWeight: FontWeight.bold, fontSize: 16),
          ),
          Expanded(
            child: Text(
              nombre.toUpperCase(),
              style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w500, letterSpacing: 1.1),
            ),
          ),
          Text(
            "$puntos €",
            style: TextStyle(color: colorPosicion, fontWeight: FontWeight.bold, fontSize: 15),
          ),
        ],
      ),
    );
  }
}