import 'package:flutter/material.dart';
import 'package:suerte/connection.dart';

class TiendaPage extends StatelessWidget {
  final int monedasActuales;
  final int idUsuario;
  final Function(int, String) onComprar;

  const TiendaPage({
    super.key,
    required this.monedasActuales,
    required this.idUsuario,
    required this.onComprar,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage('images/vale.png'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                // ── AppBar personalizada ──
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      // Flecha atrás
                      IconButton(
                        icon: const Icon(Icons.arrow_back_ios_new, color: Colors.white),
                        onPressed: () => Navigator.pop(context),
                      ),
                      // Saldo arriba a la derecha
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.5),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: Colors.amber.withOpacity(0.5)),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.monetization_on, color: Colors.amber, size: 18),
                            const SizedBox(width: 6),
                            Text(
                              "$monedasActuales",
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 220),
                // ── Lista de ítems ──
                Expanded(
                  child: ListView(
                    padding: const EdgeInsets.all(20),
                    children: [
                      _itemTienda(context, "Pista Extra", "Revela una letra", 500, Icons.help),
                      _itemTienda(context, "Escudo", "Evita perder el dinero", 1000, Icons.shield),
                      _itemTienda(context, "Anti-Quiebra", "Te salvas de PERDER TODO", 1500, Icons.shield),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _itemTienda(BuildContext context, String titulo, String desc, int precio, IconData icono) {
    bool tieneSaldo = monedasActuales >= precio;
    return Card(
      color: Colors.black.withOpacity(0.6),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: InkWell(
        borderRadius: BorderRadius.circular(15),
        onTap: tieneSaldo ? () => _mostrarConfirmacion(context, titulo, precio) : null,
        child: ListTile(
          leading: Icon(icono, color: tieneSaldo ? Colors.amberAccent : Colors.grey),
          title: Text(titulo,
              style: TextStyle(color: tieneSaldo ? Colors.white : Colors.white54, fontWeight: FontWeight.bold)),
          subtitle: Text(desc, style: const TextStyle(color: Colors.white60)),
          trailing: Text("$precio",
              style: TextStyle(
                  color: tieneSaldo ? Colors.amber : Colors.grey,
                  fontWeight: FontWeight.bold,
                  fontSize: 16)),
        ),
      ),
    );
  }

  void _mostrarConfirmacion(BuildContext context, String item, int precio) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A2E),
        title: Text("Comprar $item", style: const TextStyle(color: Colors.white)),
        content: Text("¿Quieres gastar $precio monedas en $item?",
            style: const TextStyle(color: Colors.white70)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Cancelar", style: TextStyle(color: Colors.white70)),
          ),
          ElevatedButton(
            onPressed: monedasActuales >= precio
                ? () async {
                    try {
                      ConexionDB db = ConexionDB();
                      await db.agregarAlInventario(idUsuario, item, 1);
                      await db.registrarLogro(
                        idUsuario,
                        'comprador',
                        'Realizaste tu primera compra en la tienda',
                      );
                      print("Compra guardada en inventario: $item");
                    } catch (e) {
                      print("Error al guardar inventario: $e");
                    }
                    onComprar(precio, item);
                    Navigator.pop(context);
                    Navigator.pop(context);
                  }
                : null,
            child: Text(monedasActuales >= precio ? "Comprar" : "Saldo Insuficiente"),
          ),
        ],
      ),
    );
  }
}