import 'package:flutter/material.dart';



InputDecoration estiloCuadroFormulario(String nombreEtiqueta) {
  return InputDecoration(
    
    labelText: nombreEtiqueta,
    labelStyle: TextStyle(color: Colors.amber[200]),
    filled: true,
    fillColor: Colors.black.withValues(alpha: 0.6),
    //floatingLabelBehavior: FloatingLabelBehavior.auto,
    
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(25),
    ),
    
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(25),
      borderSide: BorderSide(color: Colors.brown, width: 2),
    ),
    
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(25),
      borderSide: BorderSide(color: Colors.amber, width: 1),
    ),

    contentPadding: EdgeInsets.symmetric(vertical: 12, horizontal: 25),
  );   
  
}


Widget estiloBotonFormulario(String textoBoton, double tamanoLetra, VoidCallback accionDeOnPressed) {    
  return SizedBox(
    width: 115,
    child: OutlinedButton(
      onPressed: accionDeOnPressed,
      style: OutlinedButton.styleFrom(
        backgroundColor: Colors.black.withValues(alpha: 0.6),
        foregroundColor: Colors.amber[200],
        side: BorderSide(color: Colors.brown, width: 2),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(25),
        ),
        padding: EdgeInsets.symmetric(vertical: 12),
      ),
      child: Text(
        textoBoton,
        style: TextStyle(
          fontFamily: 'Fell',
          fontSize: tamanoLetra,
          fontWeight: FontWeight.bold,
          letterSpacing: 1,
        ),
      ),
    ),
  );

}