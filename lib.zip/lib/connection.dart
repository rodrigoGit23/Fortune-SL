import 'package:mysql1/mysql1.dart';
import 'models.dart';

class ConexionDB {
  // Abre una conexión nueva en cada llamada 
  Future<MySqlConnection> _abrir() async {
    return await MySqlConnection.connect(ConnectionSettings(
      host: '10.0.2.2',
      // host:localhost
      // host: '192.168.1.79',
      port: 3306,
      user: 'flutter',
      password: 'flutter123',
      db: 'juego_ruleta',
      timeout: Duration(seconds: 15),
    ));
  }

  // ================================================================
  // USUARIOS
  // ================================================================

  Future<Usuario?> login(String username, String password) async {
    final db = await _abrir();
    try {
      var r = await db.query(
          'SELECT id_usuario, username, password, email, monedas_globales '
          'FROM usuarios WHERE username = ? AND password = ?',
          [username, password]);
      if (r.isEmpty) return null;
      var t = r.first;
      return Usuario(
        id: t['id_usuario'],
        username: t['username'],
        password: t['password'],
        email: t['email'] ?? '',
        monedasGlobales: t['monedas_globales'] ?? 0,
      );
    } catch (e) {
      print('ERROR login: $e');
      return null;
    } finally {
      await db.close();
    }
  }

  Future<bool> registro(Usuario u) async {
    final db = await _abrir();
    try {
      await db.query(
          'INSERT INTO usuarios (username, password, email, monedas_globales) VALUES (?, ?, ?, ?)',
          [u.username, u.password, u.email, u.monedasGlobales]);
      return true;
    } catch (e) {
      print('ERROR registro: $e');
      return false;
    } finally {
      await db.close();
    }
  }

  Future<bool> existeUsuario(String username) async {
    final db = await _abrir();
    try {
      var r = await db.query(
          'SELECT 1 FROM usuarios WHERE username = ?', [username]);
      return r.isNotEmpty;
    } catch (e) {
      print('ERROR existeUsuario: $e');
      return false;
    } finally {
      await db.close();
    }
  }

  Future<void> sumarMonedas(int idUsuario, int cantidad) async {
    final db = await _abrir();
    try {
      await db.query(
          'UPDATE usuarios SET monedas_globales = monedas_globales + ? WHERE id_usuario = ?',
          [cantidad, idUsuario]);
    } catch (e) {
      print('ERROR sumarMonedas: $e');
    } finally {
      await db.close();
    }
  }

  Future<List<Usuario>> obtenerRanking() async {
    final db = await _abrir();
    try {
      var r = await db.query(
          'SELECT username, monedas_globales FROM usuarios '
          'ORDER BY monedas_globales DESC LIMIT 10');
      return r.map((t) => Usuario(
            id: 0,
            username: t['username'],
            password: '',
            email: '',
            monedasGlobales: t['monedas_globales'] ?? 0,
          )).toList();
    } catch (e) {
      print('ERROR obtenerRanking: $e');
      return [];
    } finally {
      await db.close();
    }
  }

  // ================================================================
  // FRASES
  // ================================================================

  Future<Map<String, dynamic>?> obtenerFraseAleatoria() async {
    final db = await _abrir();
    try {
      var r = await db.query(
          'SELECT id_frase, texto, categoria FROM frases ORDER BY RAND() LIMIT 1');
      if (r.isEmpty) return null;
      return {
        'id_frase': r.first['id_frase'],
        'texto': r.first['texto'],
        'categoria': r.first['categoria'],
      };
    } catch (e) {
      print('ERROR obtenerFraseAleatoria: $e');
      return null;
    } finally {
      await db.close();
    }
  }

  // ================================================================
  // PARTIDAS
  // ================================================================

  Future<int?> iniciarPartida(int idUsuario) async {
    final db = await _abrir();
    try {
      var r = await db.query(
          'INSERT INTO partidas (id_usuario, puntos_totales) VALUES (?, 0)',
          [idUsuario]);
      return r.insertId;
    } catch (e) {
      print('ERROR iniciarPartida: $e');
      return null;
    } finally {
      await db.close();
    }
  }

  Future<void> finalizarPartida(int idPartida, int puntosFinales) async {
    final db = await _abrir();
    try {
      await db.query(
          'UPDATE partidas SET puntos_totales = ? WHERE id_partida = ?',
          [puntosFinales, idPartida]);
    } catch (e) {
      print('ERROR finalizarPartida: $e');
    } finally {
      await db.close();
    }
  }

  // ================================================================
  // MOVIMIENTOS
  // ================================================================

  Future<void> registrarMovimiento(
      int idPartida, String accion, int valorObtenido) async {
    final db = await _abrir();
    try {
      await db.query(
          'INSERT INTO movimientos (id_partida, accion, valor_obtenido) VALUES (?, ?, ?)',
          [idPartida, accion, valorObtenido]);
    } catch (e) {
      print('ERROR registrarMovimiento: $e');
    } finally {
      await db.close();
    }
  }

  // ================================================================
  // INVENTARIO
  // ================================================================

  Future<void> agregarAlInventario(
      int idUsuario, String nombreItem, int cantidad) async {
    final db = await _abrir();
    try {
      var existe = await db.query(
          'SELECT id_inv FROM inventario WHERE id_usuario = ? AND nombre_item = ?',
          [idUsuario, nombreItem]);
      if (existe.isNotEmpty) {
        await db.query(
            'UPDATE inventario SET cantidad = cantidad + ? WHERE id_inv = ?',
            [cantidad, existe.first['id_inv']]);
      } else {
        await db.query(
            'INSERT INTO inventario (id_usuario, nombre_item, cantidad) VALUES (?, ?, ?)',
            [idUsuario, nombreItem, cantidad]);
      }
    } catch (e) {
      print('ERROR agregarAlInventario: $e');
    } finally {
      await db.close();
    }
  }

  Future<List<Map<String, dynamic>>> obtenerInventario(int idUsuario) async {
    final db = await _abrir();
    try {
      var r = await db.query(
          'SELECT nombre_item, cantidad FROM inventario WHERE id_usuario = ? ORDER BY nombre_item',
          [idUsuario]);
      return r.map((t) => {
            'nombre_item': t['nombre_item'],
            'cantidad': t['cantidad'],
          }).toList();
    } catch (e) {
      print('ERROR obtenerInventario: $e');
      return [];
    } finally {
      await db.close();
    }
  }

  // ================================================================
// LOGROS
// ================================================================

Future<void> registrarLogro(int idUsuario, String tipoLogro, String descripcion) async {
  final db = await _abrir();
  try {
    // Evita duplicados: solo guarda el logro si no existe ya para ese usuario
    var existe = await db.query(
      'SELECT 1 FROM logros WHERE id_usuario = ? AND tipo_logro = ?',
      [idUsuario, tipoLogro],
    );
    if (existe.isEmpty) {
      await db.query(
        'INSERT INTO logros (id_usuario, tipo_logro, descripcion) VALUES (?, ?, ?)',
        [idUsuario, tipoLogro, descripcion],
      );
      print('🏆 Logro desbloqueado: $tipoLogro');
    }
  } catch (e) {
    print('ERROR registrarLogro: $e');
  } finally {
    await db.close();
  }
}

Future<List<Map<String, dynamic>>> obtenerLogros(int idUsuario) async {
  final db = await _abrir();
  try {
    var r = await db.query(
      'SELECT tipo_logro, descripcion, fecha FROM logros WHERE id_usuario = ? ORDER BY fecha DESC',
      [idUsuario],
    );
    return r.map((t) => {
      'tipo_logro': t['tipo_logro'],
      'descripcion': t['descripcion'],
      'fecha': t['fecha'].toString(),
    }).toList();
  } catch (e) {
    print('ERROR obtenerLogros: $e');
    return [];
  } finally {
    await db.close();
  }
}
}
