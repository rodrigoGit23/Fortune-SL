import 'package:flutter/material.dart';
import 'package:suerte/first.dart';
import 'package:suerte/login.dart';
import 'package:suerte/ranking.dart';
import 'package:suerte/registro.dart';
 

void main() {
  runApp(const Ruleta());
}

class Ruleta extends StatelessWidget {
  const Ruleta({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ruleta de la suerte',
      initialRoute: "/registro", 
      routes: {
        '/registro': (BuildContext context) => Registro(),
        '/login': (BuildContext context) => LoginStateful(),
        // "/first": (BuildContext context) => Principal(),
        '/ranking': (context) => Ranking(),
      },
    );
  }
}


// import 'package:flutter/material.dart';
// import 'package:suerte/first.dart';    // Asegúrate de importar tu pantalla de juego
// import 'package:suerte/ranking.dart';  // Asegúrate de importar el ranking
// import 'package:suerte/models.dart';   // Necesitamos el modelo Usuario para el dato falso

// void main() {
//   runApp(const Ruleta());
// }

// class Ruleta extends StatelessWidget {
//   const Ruleta({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       title: 'Ruleta de la suerte',
//       // Esto hace que la app inicie directamente en el Juego
//       home: Principal(
//         usuario: Usuario(
//           id: 1, 
//           username: 'JugadorPrueba', 
//           password: '', 
//           email: '', 
//           monedasGlobales: 500
//         ),
//       ),
      
//       // Mantenemos el ranking aquí por si quieres navegar a él desde el juego
//       routes: {
//         '/ranking': (BuildContext context) => Ranking(),
//       },
//     );
//   }
// }