import 'package:flutter/material.dart';
import 'package:suerte/first.dart';
import 'package:suerte/main.dart';
import '../connection.dart';
import '../dialogs.dart';
import '../models.dart';

class LoginStateful extends StatefulWidget {
  @override
  LoginEstado createState() => LoginEstado();
}

class LoginEstado extends State<LoginStateful> {
  String imgFondo = 'images/fondo_login.png';
  String nombre = '';
  String password = '';
  var keyFormLogin = GlobalKey<FormState>();

  recogerDatosLogin(BuildContext context) async { 
    print("DEBUG: Se ha pulsado el botón JUGAR.");
    if (keyFormLogin.currentState!.validate()) {
      keyFormLogin.currentState!.save();

      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) => const Center(
          child: CircularProgressIndicator(color: Colors.amber),
        ),
      );


      ConexionDB db = ConexionDB();
      print("DEBUG: Intentando login para: $nombre");

      Usuario? usuarioLogin = await db.login(nombre, password);
      print("DEBUG: Respuesta recibida. ¿Es null?: ${usuarioLogin == null}");

      if (usuarioLogin != null && usuarioLogin.id != 0) {
        print("Login exitoso. Usuario: ${usuarioLogin.username} con ID: ${usuarioLogin.id}");

        Navigator.of(context).pushReplacement(
          MaterialPageRoute(
            builder: (context) => Principal(usuario: usuarioLogin),
          ),
        );
}else {
    print("DEBUG: Login fallido. Usuario incorrecto o ID 0.");

        bool animarReintentar = false;
        bool animarRegistrarme = false;

        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (BuildContext context) {
            return StatefulBuilder(
              builder: (context, setStateDialog) {
                return AlertDialog(
                  backgroundColor: Colors.grey[900], // Fondo oscuro de tu ruleta
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                  title: Row(
                    children: [
                      Icon(Icons.error_outline, color: Colors.amber, size: 28),
                      SizedBox(width: 10),
                      Text(
                        "Error de acceso",
                        style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18),
                      ),
                    ],
                  ),
                  content: Text(
                    'No se ha podido iniciar sesión.\n\nNombre de usuario y/o contraseña incorrectos o registro no completado.',
                    style: TextStyle(color: Colors.white70, fontSize: 14, height: 1.4),
                  ),
                  actionsPadding: EdgeInsets.only(bottom: 25, left: 15, right: 15),
                  actions: [
                    Row(
                      children: [
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.only(right: 6),
                            child: MouseRegion(
                              opaque: true, 
                              onEnter: (_) => setStateDialog(() => animarReintentar = true),
                              onExit: (_) => setStateDialog(() => animarReintentar = false),
                              cursor: SystemMouseCursors.click,
                              child: GestureDetector(
                                onTap: () {
                                  Navigator.pop(context); // Cierra el diálogo de error limpiamente
                                },
                                child: AnimatedContainer(
                                  duration: Duration(milliseconds: 150),
                                  curve: Curves.easeInOut,
                                  // Se transforma un 5% más grande única y exclusivamente con el ratón encima
                                  transform: animarReintentar 
                                      ? (Matrix4.identity()..translate(0.0, -2.0)..scale(1.05)) 
                                      : Matrix4.identity(),
                                  padding: EdgeInsets.symmetric(vertical: 12),
                                  decoration: BoxDecoration(
                                    color: animarReintentar ? Colors.amber[500] : Colors.amber[700],
                                    borderRadius: BorderRadius.circular(15),
                                    boxShadow: animarReintentar ? [
                                      BoxShadow(
                                        color: Colors.amber.withOpacity(0.5),
                                        blurRadius: 10,
                                        offset: Offset(0, 4),
                                      )
                                    ] : [],
                                  ),
                                  child: Center(
                                    child: Text(
                                      "REINTENTAR",
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 13,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),

                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.only(left: 6),
                            child: MouseRegion(
                              opaque: true, // CLAVE: Obliga a responder a los eventos del puntero del ratón
                              onEnter: (_) => setStateDialog(() => animarRegistrarme = true),
                              onExit: (_) => setStateDialog(() => animarRegistrarme = false),
                              cursor: SystemMouseCursors.click,
                              child: GestureDetector(
                                onTap: () {
                                  Navigator.pop(context); // Cierra el diálogo de error
                                  Navigator.pushNamed(context, '/registro'); // Redirige de forma nativa
                                },
                                child: AnimatedContainer(
                                  duration: Duration(milliseconds: 150),
                                  curve: Curves.easeInOut,
                                  // Mismo comportamiento visual de escala solo activa por hover
                                  transform: animarRegistrarme 
                                      ? (Matrix4.identity()..translate(0.0, -2.0)..scale(1.05)) 
                                      : Matrix4.identity(),
                                  padding: EdgeInsets.symmetric(vertical: 12),
                                  decoration: BoxDecoration(
                                    color: animarRegistrarme ? Colors.amber[500] : Colors.amber[700],
                                    borderRadius: BorderRadius.circular(15),
                                    boxShadow: animarRegistrarme ? [
                                      BoxShadow(
                                        color: Colors.amber.withOpacity(0.5),
                                        blurRadius: 10,
                                        offset: Offset(0, 4),
                                      )
                                    ] : [],
                                  ),
                                  child: Center(
                                    child: Text(
                                      "REGISTRARME",
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 13,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                );
              },
            );
          },
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: Stack(
          children: [
            Positioned.fill(
              child: Image.asset(
                imgFondo,
                fit: BoxFit.cover,
              ),
            ),

            Positioned.fill(
              child: Container(
                color: Colors.black.withOpacity(0.1),
              ),
            ),
            
            // 4. FORMULARIO CENTRADO
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 30),
              child: Form(
                key: keyFormLogin,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(height: 30),
                    _crearInput(
                      label: "Nombre de Usuario",
                      icon: Icons.person,
                      onSave: (val) => nombre = val!,
                    ),
                    _crearInput(
                      label: "Contraseña",
                      icon: Icons.lock,
                      isPassword: true,
                      onSave: (val) => password = val!,
                    ),
                    SizedBox(height: 10),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.amber[700],
                        foregroundColor: Colors.black,
                        minimumSize: Size(double.infinity, 50),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                      ),
                      onPressed: () => recogerDatosLogin(context),
                      child: Text("JUGAR", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    ),
                    SizedBox(height: 10),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _crearInput({
    required String label,
    required IconData icon,
    required Function(String?) onSave,
    bool isPassword = false,
  }) {
    return Padding(
      padding: EdgeInsets.only(bottom: 20),
      child: TextFormField(
        obscureText: isPassword,
        style: TextStyle(color: Colors.white),
        decoration: InputDecoration(
          prefixIcon: Icon(icon, color: Colors.amber),
          labelText: label,
          labelStyle: TextStyle(color: Colors.amber[200]),
          filled: true,
          fillColor: Colors.black45,
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.amber.withOpacity(0.5)),
            borderRadius: BorderRadius.circular(15),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.amber, width: 2),
            borderRadius: BorderRadius.circular(15),
          ),
          // MODIFICACIÓN: Cambia las líneas inferiores por defecto (Rojas) al color corporativo dorado amarillento
          errorBorder: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.amberAccent, width: 1.5),
            borderRadius: BorderRadius.circular(15),
          ),
          focusedErrorBorder: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.amberAccent, width: 2),
            borderRadius: BorderRadius.circular(15),
          ),
          errorStyle: TextStyle(color: Colors.amberAccent, fontWeight: FontWeight.bold),
        ),
        onSaved: onSave,
        validator: (val) => (val == null || val.isEmpty) ? "Campo obligatorio" : null,
      ),
    );
  }
}